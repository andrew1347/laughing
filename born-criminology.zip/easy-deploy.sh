#!/bin/bash

echo "🚀 天生犯罪人网站一键部署工具"
echo "================================="
echo ""

# 检查Git是否安装
if ! command -v git &> /dev/null; then
    echo "❌ 错误：Git未安装"
    echo "请先安装Git："
    echo "  - Ubuntu/Debian: sudo apt install git"
    echo "  - macOS: brew install git 或从官网下载"
    echo "  - Windows: 从 https://git-scm.com/downloads 下载安装"
    exit 1
fi

echo "✅ Git已安装"
echo ""

# 获取GitHub用户名
read -p "请输入您的GitHub用户名: " github_username

if [ -z "$github_username" ]; then
    echo "❌ 用户名不能为空"
    exit 1
fi

echo ""
echo "📝 正在配置Git..."
git config --global user.name "Born Criminology User"
git config --global user.email "born-criminology@example.com"
echo "✅ Git配置完成"

echo ""
echo "📂 正在初始化Git仓库..."
git init
echo "✅ Git仓库初始化完成"

echo ""
echo "📄 正在添加文件..."
git add index.html deployment-guide.md deploy.sh test-fix.html GIT-DEPLOY-GUIDE.md easy-deploy.sh
echo "✅ 文件添加完成"

echo ""
echo "💬 正在创建提交..."
git commit -m "部署天生犯罪人学术论文分享平台 $(date +'%Y-%m-%d')"
echo "✅ 提交创建完成"

echo ""
echo "🌐 正在连接GitHub仓库..."
github_repo="https://github.com/$github_username/$github_username.github.io.git"
git remote add origin $github_repo
echo "✅ 已连接到: $github_repo"

echo ""
echo "🔐 提示：首次推送需要GitHub凭证"
echo "如果使用密码登录失败，请使用个人访问令牌："
echo "1. 访问 https://github.com/settings/tokens"
echo "2. 创建新令牌，选择 'repo' 权限"
echo "3. 复制令牌，在下面提示时粘贴"
echo ""
echo "📤 正在推送到GitHub..."
echo "（请输入GitHub的用户名和密码/令牌）"
echo ""

# 推送代码
git push -u origin master

if [ $? -eq 0 ]; then
    echo ""
    echo "🎉 部署成功！"
    echo ""
    echo "🔗 您的网站地址：https://$github_username.github.io"
    echo ""
    echo "⏳ 请等待几分钟让GitHub Pages生效"
    echo ""
    echo "📋 后续更新步骤："
    echo "1. 修改文件"
    echo "2. 运行：git add ."
    echo "3. 运行：git commit -m \"更新说明\""
    echo "4. 运行：git push"
    echo ""
    echo "❓ 有问题？查看 GIT-DEPLOY-GUIDE.md 获取详细帮助"
else
    echo ""
    echo "❌ 部署失败"
    echo "常见问题："
    echo "1. GitHub仓库不存在 - 请先在GitHub创建仓库"
    echo "2. 凭证错误 - 请检查用户名和密码/令牌"
    echo "3. 网络问题 - 请检查网络连接"
    echo ""
    echo "查看 GIT-DEPLOY-GUIDE.md 获取详细解决方案"
fi