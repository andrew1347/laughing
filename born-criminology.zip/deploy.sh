#!/bin/bash

echo "========================================="
echo "天生犯罪人学术论文分享平台部署脚本"
echo "========================================="

# 检查Git是否安装
if ! command -v git &> /dev/null; then
    echo "错误：Git未安装，请先安装Git"
    exit 1
fi

echo ""
echo "请选择部署方式："
echo "1) GitHub Pages（推荐）"
echo "2) 本地测试服务器"
echo "3) 退出"
echo ""

read -p "请输入选项 [1-3]: " choice

case $choice in
    1)
        echo ""
        echo "=== GitHub Pages 部署 ==="
        echo ""
        
        # 获取GitHub用户名
        read -p "请输入您的GitHub用户名: " github_username
        
        # 配置Git
        echo "配置Git..."
        git config --global user.name "Born Criminology User"
        git config --global user.email "born-criminology@example.com"
        
        # 初始化仓库
        echo "初始化Git仓库..."
        git init
        
        # 添加文件
        echo "添加项目文件..."
        git add index.html deployment-guide.md deploy.sh
        
        # 提交
        echo "创建提交..."
        git commit -m "部署天生犯罪人学术论文分享平台 $(date)"
        
        # 添加远程仓库
        echo "连接到GitHub仓库..."
        git remote add origin https://github.com/$github_username/$github_username.github.io.git
        
        # 推送
        echo "推送代码到GitHub..."
        echo "注意：这将要求您输入GitHub的用户名和密码或访问令牌"
        git push -u origin master
        
        echo ""
        echo "=== 部署完成 ==="
        echo "请在浏览器中访问：https://$github_username.github.io"
        echo ""
        echo "如果遇到权限错误，请创建GitHub个人访问令牌："
        echo "1. 访问 https://github.com/settings/tokens"
        echo "2. 创建新令牌，选择 'repo' 权限"
        echo "3. 使用令牌作为密码"
        ;;
        
    2)
        echo ""
        echo "=== 启动本地测试服务器 ==="
        echo ""
        
        # 检查Python是否安装
        if ! command -v python3 &> /dev/null; then
            echo "错误：Python3未安装，请先安装Python3"
            exit 1
        fi
        
        echo "启动本地服务器在端口8000..."
        echo "请在浏览器中访问：http://localhost:8000"
        echo "按 Ctrl+C 停止服务器"
        echo ""
        
        python3 -m http.server 8000
        ;;
        
    3)
        echo "退出部署"
        exit 0
        ;;
        
    *)
        echo "无效选项，请重新运行脚本"
        exit 1
        ;;
esac