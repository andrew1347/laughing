# 🚀 Git部署超简单指南

## 什么是Git？
Git就像是一个"时间机器"，可以保存您的文件历史，并帮助您将代码上传到互联网。

## 🔧 第一步：安装Git（如果还没安装）
```bash
# 检查是否已安装Git
git --version

# 如果没有安装，会提示您安装
```

## 📝 第二步：配置Git（只需做一次）
```bash
# 设置您的名字
git config --global user.name "您的名字"

# 设置您的邮箱
git config --global user.email "您的邮箱@example.com"
```

## 🚩 第三步：初始化Git仓库
```bash
# 进入您的项目文件夹
cd /home/user/vibecoding/workspace/born-criminology

# 初始化Git（创建.git文件夹）
git init
```

## 📁 第四步：添加文件
```bash
# 添加所有文件到Git
git add .

# 或者只添加特定文件
git add index.html
```

## 💬 第五步：提交更改
```bash
# 提交您的文件，添加一个说明
git commit -m "部署天生犯罪人网站"
```

## 🌐 第六步：连接GitHub（重要！）
1. **先在GitHub网站上创建仓库**：
   - 访问 https://github.com
   - 登录您的账号
   - 点击"New repository"
   - 仓库名：`您的用户名.github.io`
   - 选择"Public"
   - 点击"Create repository"

2. **复制仓库链接**：
   看起来像这样：`https://github.com/您的用户名/您的用户名.github.io.git`

3. **连接到GitHub**：
```bash
# 添加远程仓库（粘贴您复制的链接）
git remote add origin https://github.com/您的用户名/您的用户名.github.io.git
```

## 📤 第七步：上传到GitHub
```bash
# 推送到GitHub
git push -u origin master

# 首次推送会要求输入GitHub的用户名和密码
# 现在GitHub使用个人访问令牌作为密码，请创建一个：
# https://github.com/settings/tokens
```

## ✅ 第八步：启用GitHub Pages
1. 进入您的GitHub仓库
2. 点击"Settings"
3. 找到"Pages"
4. 在"Source"中选择"master branch"
5. 点击"Save"
6. 等待几分钟...

## 🎉 第九步：访问您的网站！
您的网站地址：`https://您的用户名.github.io`

## 🔄 更新网站（修改后）
```bash
# 添加更改的文件
git add .

# 提交更改
git commit -m "更新内容"

# 推送到GitHub
git push
```

## ❌ 常见问题解决

### 问题1：推送失败
```bash
# 先拉取最新代码（如果有冲突）
git pull origin master

# 然后再推送
git push origin master
```

### 问题2：忘记密码
- 去GitHub创建个人访问令牌：https://github.com/settings/tokens
- 权限选择：`repo`
- 使用令牌作为密码

### 问题3：文件没有变化
```bash
# 检查状态
git status

# 确保文件被跟踪
git add .
```

## 📋 快速命令表
```bash
# 初始化
git init

# 添加文件
git add .

# 提交
git commit -m "说明"

# 推送
git push origin master

# 查看状态
git status

# 查看日志
git log
```

---

**天生犯罪人** - 让每一篇研究都有展示的机会！
"即使是垃圾，亦可以长长久久"