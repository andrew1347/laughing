# "天生犯罪人"学术论文分享平台部署指南

## 快速部署选项

### 选项1：GitHub Pages（推荐）

1. **创建GitHub账号**
   - 访问 https://github.com
   - 注册账号并登录

2. **创建仓库**
   - 点击"New repository"
   - 仓库名称：`your-username.github.io`（替换为您的GitHub用户名）
   - 选择"Public"
   - 勾选"Add a README file"
   - 点击"Create repository"

3. **上传项目文件**
   ```bash
   # 在项目目录中执行
   cd /home/user/vibecoding/workspace/born-criminology
   
   # 初始化Git仓库
   git init
   git config --global user.name "Your Name"
   git config --global user.email "your.email@example.com"
   
   # 添加文件
   git add index.html deployment-guide.md
   git commit -m "部署天生犯罪人学术论文分享平台"
   
   # 连接到GitHub仓库
   git remote add origin https://github.com/your-username/your-username.github.io.git
   
   # 推送代码
   git push -u origin master
   ```

4. **启用GitHub Pages**
   - 进入仓库 → Settings → Pages
   - 在"Source"中选择"master branch"
   - 点击"Save"
   - 等待几分钟后，访问 https://your-username.github.io

### 选项2：Netlify

1. **访问Netlify**
   - 访问 https://app.netlify.com
   - 注册账号并登录

2. **部署网站**
   - 点击"Add new site" → "Deploy manually"
   - 拖拽项目文件夹或点击上传
   - 等待部署完成
   - 获取分配的Netlify域名

## 本地测试

在部署前，可以在本地测试网站：

```bash
# 启动本地服务器
cd /home/user/vibecoding/workspace/born-criminology
python3 -m http.server 8000

# 在浏览器中访问
# http://localhost:8000
```

## 自定义域名（可选）

如果您有自己的域名：

1. **购买域名**（阿里云、腾讯云等）
2. **配置DNS**
   - GitHub Pages: 添加CNAME记录指向 your-username.github.io
   - Netlify: 在Netlify设置中添加自定义域名

## 部署成功后

- 网站地址：https://your-username.github.io（GitHub Pages）
- 或：https://your-site.netlify.app（Netlify）

## 后续维护

- 更新内容后，重新推送代码即可自动部署
- 定期检查网站访问情况
- 根据用户反馈进行优化

---

**天生犯罪人** - 打破学术垄断，分享研究成果
"即使是垃圾，亦可以长长久久"